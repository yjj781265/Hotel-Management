﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Valet
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ArrayList name = new ArrayList();
        ArrayList ticketnum = new ArrayList();
        ArrayList platenum = new ArrayList();
        ArrayList make = new ArrayList();
        ArrayList color = new ArrayList();
        ArrayList modelL = new ArrayList();
        ArrayList location = new ArrayList();
        ArrayList carMaker = new ArrayList();
        ArrayList colorList = new ArrayList();
        ArrayList typeList = new ArrayList();
        int i = 0;
        int counter = 0;
        bool removeButton = false;

        public MainWindow()
        {
            InitializeComponent();
            this.Title = "Valet";
            makeBox.IsEditable = true;
            carMaker.Add("ACURA");          // SET UP CARMAKE ARRAYLIST
            carMaker.Add("ALFA ROMEO");
            carMaker.Add("ASTON MARTIN");
            carMaker.Add("AUDI");
            carMaker.Add("BENTLEY");
            carMaker.Add("BMW");
            carMaker.Add("BUGATTI");
            carMaker.Add("BUICK");
            carMaker.Add("CARDILLAC");
            carMaker.Add("CHEVROLET");
            carMaker.Add("CHRYSLER");
            carMaker.Add("CITROEN");
            carMaker.Add("DODGE");
            carMaker.Add("FERRARI");
            carMaker.Add("FIAT");
            carMaker.Add("FORD");
            carMaker.Add("GEELY");
            carMaker.Add("GENERAL MOTORS");
            carMaker.Add("GMC");
            carMaker.Add("HONDA");
            carMaker.Add("HYUNDAI");
            carMaker.Add("INFINITI");
            carMaker.Add("JAGUAR");
            carMaker.Add("JEEP");
            carMaker.Add("KIA");
            carMaker.Add("KOENIGSEGG");
            carMaker.Add("LAMBORGHINI");
            carMaker.Add("LAND ROVER");
            carMaker.Add("LEXUS");
            carMaker.Add("MASERATI");
            carMaker.Add("MAZDA");
            carMaker.Add("MCLAREN");
            carMaker.Add("MERCEDES-BENZ");
            carMaker.Add("MINI");
            carMaker.Add("MITSUBISHI");
            carMaker.Add("PAGANI");
            carMaker.Add("PEUGEOT");
            carMaker.Add("PORSCHE");
            carMaker.Add("NISSAN");
            carMaker.Add("RAM");
            carMaker.Add("RENAULT");
            carMaker.Add("ROLLS ROYCE");
            carMaker.Add("SAAB");
            carMaker.Add("SUBARU");
            carMaker.Add("SUZUKI");
            carMaker.Add("TATA MOTORS");
            carMaker.Add("TESLA");
            carMaker.Add("TOYOTA");
            carMaker.Add("VOLKSWAGEN");
            carMaker.Add("VOLVO");
            makeBox.ItemsSource = carMaker;

            colorList.Add("WHITE");   // colorList setup
            colorList.Add("SILVER");
            colorList.Add("BLACK");
            colorList.Add("BLUE");
            colorList.Add("RED");
            colorList.Add("ORANGE");
            colorList.Add("YELLOW");
            colorList.Add("BROWN");
            colorList.Add("OTHER");
            colorBox.ItemsSource = colorList;

            typeList.Add("2 DOOR");
            typeList.Add("4 DOOR");
            typeList.Add("MOTOCYCLE");
            typeList.Add("CONVERTIBLE");
            typeList.Add("SUV");
            typeList.Add("HATCHBACK");
            typeList.Add("PICKUP TRUCK");
            typeList.Add("VAN");
            typeList.Add("OTHER");
            TypeBox.ItemsSource = typeList;
            textBoxC.IsReadOnly = true;
            textBoxT.IsReadOnly = true;
            textBoxMa.IsReadOnly = true;
            textBoxMo.IsReadOnly = true;
            textBoxL.IsReadOnly = true;
            textBoxP.IsReadOnly = true;
            plateTextBox.CharacterCasing = CharacterCasing.Upper; // covert to uppercase  

        }
        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (removeButton == false)
            {
                string str = listBox.SelectedItem as string;
                for (int j = 0; j < name.Count; j++)
                {
                    if (str.Equals(name[j].ToString()) && !String.IsNullOrWhiteSpace(str))
                    {
                        textBoxP.Text = platenum[j].ToString();
                        textBoxMa.Text = make[j].ToString();
                        textBoxC.Text = color[j].ToString();
                        textBoxT.Text = ticketnum[j].ToString();
                        /* textBoxL.Text = location[j].ToString();*/
                        textBoxMo.Text = modelL[j].ToString();
                        Console.Out.WriteLine("the index" + j);
                        removeButton = false;
                    }

                }
            }
            else if (removeButton == true)
            {
                removeButton = false;
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
            bool flag = ticketCheck(ticketTextBox);
            Console.Out.WriteLine(i);
        

            if (!string.IsNullOrWhiteSpace(nameTextBox.Text) && flag)
            {
                name.Add(nameTextBox.Text);
                ticketnum.Add(ticketTextBox.Text);

                platenum.Add(plateTextBox.Text);
                make.Add(makeBox.Text);
                color.Add(colorBox.Text);
                modelL.Add(TypeBox.Text);
                listBox.Items.Add(name[i]);
                listBox.Items.SortDescriptions.Add(
new SortDescription("", ListSortDirection.Ascending));                     // sort listbox name in alpbetical order



                i++;
                System.Windows.MessageBox.Show("The informations have sent to the database");
                nameTextBox.Text = string.Empty;
                ticketTextBox.Text = string.Empty;
                plateTextBox.Text = string.Empty;
                makeBox.Text = string.Empty;
                colorBox.Text = string.Empty;
                TypeBox.Text = string.Empty;


            }
            else if (string.IsNullOrWhiteSpace(nameTextBox.Text))
            {
                System.Windows.MessageBox.Show("The name is requried");
            }
            else if (flag == false)
            {
                System.Windows.MessageBox.Show("The ticket is occupied");
                ticketTextBox.Text = string.Empty;
                flag = true;

            }

        }

        private bool ticketCheck(TextBox t)
        {
            bool flag;
            for (int K = 0; i < ticketnum.Count; K++)
            {
                if (ticketnum[i].Equals(t.Text) && !string.IsNullOrWhiteSpace(t.Text))
                {
                    counter++;

                }
            }
            if (counter >= 1)
            {
                flag = false;
                counter--;

            }
            else
            {
                flag = true;
            }
            return flag;

        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            removeButton = true;
            String matchStr = listBox.SelectedItem.ToString();
            listBox.Items.Remove(listBox.SelectedItem);
            for(int j =0; j< name.Count; j++)
            {
                if (name[j].ToString().Equals(matchStr))
                {
                    name.RemoveAt(j);
                    ticketnum.RemoveAt(j);
                    platenum.RemoveAt(j);
                    make.RemoveAt(j);
                    color.RemoveAt(j);
                    modelL.RemoveAt(j);
                    i--;

                }
            }


            textBoxP.Text = string.Empty;
            textBoxC.Text = string.Empty;
            textBoxL.Text = string.Empty;
            textBoxMa.Text = string.Empty;
            textBoxMo.Text = string.Empty;
            textBoxT.Text = string.Empty;
        }







        private void search(object sender, TextChangedEventArgs e)
        {
            string txtOrig = searchBox.Text;
            string upper = txtOrig.ToUpper();
            string lower = txtOrig.ToLower();
            for(int a =0; a < name.Count; a++)
            {
                string str = name[a].ToString();
                if(!String.IsNullOrWhiteSpace(txtOrig) && (str.Trim().StartsWith(lower) || str.Trim().StartsWith(upper) || str.Trim().Contains(txtOrig)))
                {
                    listBox.Items.Clear();
                    listBox.Items.Add(name[a]);
                    listBox.Items.Refresh();
                    
                    break;
                   
                }else if (String.IsNullOrWhiteSpace(txtOrig))
                {
                    
                        listBox.Items.Clear();
                        listBox.Items.Add(name[a]);
                        listBox.Items.Refresh();
                    
                }
            }

        }

        
    }
}
