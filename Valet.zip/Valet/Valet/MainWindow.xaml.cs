﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Valet
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        ArrayList ticketnum = new ArrayList();
        ArrayList platenum = new ArrayList();
        ArrayList make = new ArrayList();
        ArrayList color = new ArrayList();
        ArrayList location = new ArrayList();
        int i = 0;
        bool removeButton = false;

        public MainWindow()
        {
            InitializeComponent();
            this.Title = "Valet";

        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (removeButton == false)
            {
                string str = listBox.SelectedItem as string;
                for (int j = 0; j < ticketnum.Count; j++)
                {
                    if (str.Equals(ticketnum[j]))
                    {
                        textBox.Text = platenum[j].ToString();
                        textBox1.Text = make[j].ToString();
                        textBox2.Text = color[j].ToString();
                        textBox3.Text = location[j].ToString();
                        removeButton = false;
                     }

                }
            }else if(removeButton == true)
            {
                removeButton = false;
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {


            Window1 popup = new Window1();
            popup.ShowDialog();
            if (popup.textBox.Text != "")
            {
                ticketnum.Add(popup.textBox.Text);
                platenum.Add(popup.textBox2.Text);
                make.Add(popup.textBox3.Text);
                color.Add(popup.textBox4.Text);
                location.Add(popup.textBox5.Text);
                textBox.Text = platenum[i].ToString();
                listBox.Items.Add(ticketnum[i]);
               
                i++;
            }else
            {
                System.Windows.MessageBox.Show("Ticket number is required");
            }



        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            removeButton = true;
            listBox.Items.Remove(listBox.SelectedItem);
            

        }



            

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }
    }
}
